// Uart.c
// Runs on LM4F120/TM4C123
// Use UART1 to implement bidirectional data transfer to and from 
// another microcontroller in Lab 9.  This time, interrupts and FIFOs
// are used.
// Daniel Valvano
// November 14, 2018
// Modified by EE345L students Charlie Gough && Matt Hawk
// Modified by EE345M students Agustinus Darmawan && Mingjie Qiu

/* Lab solution, Do not post
 http://users.ece.utexas.edu/~valvano/
*/

// This U0Rx PC4 (in) is connected to other LaunchPad PC5 (out)
// This U0Tx PC5 (out) is connected to other LaunchPad PC4 (in)
// This ground is connected to other LaunchPad ground

#include <stdint.h>
#include "Fifo.h"
#include "Uart.h"
#include "../inc/tm4c123gh6pm.h"

#define PF2       (*((volatile uint32_t *)0x40025010))

uint32_t DataLost;

int errorcount;
// Initialize UART1
// Baud rate is 115200 bits/sec
// Make sure to turn ON UART1 Receiver Interrupt (Interrupt 6 in NVIC)
// Write UART1_Handler
void Uart_Init(void){
	int delay = 0;
	
	errorcount = 0;
	
  SYSCTL_RCGCUART_R |= 0x2;																												// activate UART1 (Port C), 7 zeros
	SYSCTL_RCGCGPIO_R |= 0x4;																												// activate Port C , 7 zeros
	delay++;
	delay++;
	delay++;
	delay++;
	delay++;
	delay++;
	delay++;
	delay++;
	
	
	UART1_CTL_R &= ~0x1;																														// disable UART, 7 zeros
	UART1_IBRD_R = 43;																															// IBRD = (80000000/16*115200) = 43.4028
	UART1_FBRD_R = 26;																															// FBRD = 0.4028*64 = 25.7792
	UART1_LCRH_R = 0x70;																														// enable FIFO, 2 zeros
	GPIO_PORTC_DEN_R |= 0x30;																												// digital enable
	GPIO_PORTC_AFSEL_R |= 0x30;																											// enable alt for PC4 and PC5
	GPIO_PORTC_PCTL_R = (GPIO_PORTC_PCTL_R & 0xFF00FFFF) + 0x00220000;
	GPIO_PORTC_AMSEL_R &= ~0x30;																										// disable analog
	
	UART1_IM_R |= 0x10;																															// Arm RXRIS
	UART1_IFLS_R = (UART1_IFLS_R & ~0x38) + 0x10;																		// set bits 5,4, and 3 to 010
	NVIC_PRI1_R = (NVIC_PRI1_R & 0xFFFF00FF) | 0x4000;															// 4 zeros
	NVIC_EN0_R = 0x40;																										// set bit 6
	UART1_CTL_R |= 0x0301;																													// enable UART, TXE, and RXE
	Fifo_Init();
}

// input ASCII character from UART
// spin if RxFifo is empty
// Receiver is interrupt driven
char Uart_InChar(void){
	while ((UART1_FR_R&0x0010) != 0){																								// wait for RXFE to be 0
		return ((uint8_t) (UART1_DR_R & 0xFF));
	}
}

//------------UART1_InMessage------------
// Accepts ASCII characters from the serial port
//    and adds them to a string until ETX is typed
//    or until max length of the string is reached.
// Input: pointer to empty buffer of 8 characters
// Output: Null terminated string
// THIS FUNCTION IS OPTIONAL
void UART1_InMessage(char *bufPt){
}


//------------UART1_OutChar------------
// Output 8-bit to serial port
// Input: letter is an 8-bit ASCII character to be transferred
// Output: none
// Transmitter is busywait
void Uart_OutChar(char data){
	while(UART1_FR_R & UART_FR_TXFF ){}																				// wait for TXFF in UART1_FR_R = 0, NO BRACKETS?? just ';'??, seperate?
	UART1_DR_R = (data&0xFF);
}

// hardware RX FIFO goes from 7 to 8 or more items
// UART receiver Interrupt is triggered; This is the ISR
void UART1_Handler(void){
	static uint32_t RxCounter = 0;
	PF2 ^= 0x04;
	PF2 ^= 0x04;
	
	while ((UART1_FR_R & UART_FR_RXFE) == 0){
		Fifo_Put(UART1_DR_R);
	}
	RxCounter++;
	UART1_ICR_R = 0x10;																															// acknowledgement
	PF2 ^= 0x04;
}
