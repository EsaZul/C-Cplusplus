// put prototypes for public functions, explain what it does
// put your names here, date
#include <stdint.h>
